package com.shop.Controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.jpa.Entity.NguoiDungEntity;
import com.jpa.Service.NguoiDungService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

import java.util.Optional;

@Controller
public class test {

//    @Autowired
//    private NguoiDungService nguoiDungService;
//
//    @Autowired
//    private BCryptPasswordEncoder passwordEncoder;
//
//    @GetMapping("/login")
//    public String showLoginForm(Model model) {
//        model.addAttribute("isLogin", true);
//        return "/auth/login";
//    }
//
//    @GetMapping("/register")
//    public String showRegisterForm(Model model) {
//        model.addAttribute("isLogin", false);
//        return "login_register_thymeleaf";
//    }
//
//    @PostMapping("/auth/login")
//    public String loginUser(@RequestParam String username, @RequestParam String password, RedirectAttributes redirectAttributes) {
//        Optional<NguoiDungEntity> optionalUser = nguoiDungService.findByUsername(username);
//        if (!optionalUser.isPresent() || !passwordEncoder.matches(password, optionalUser.get().getMatKhau())) {
//            redirectAttributes.addFlashAttribute("error", "Sai tài khoản hoặc mật khẩu");
//            return "redirect:/login";
//        }
//        redirectAttributes.addFlashAttribute("success", "Đăng nhập thành công!");
//        return "redirect:/home";
//    }
//
//    @PostMapping("/auth/register")
//    public String registerUser(@RequestParam String username, @RequestParam String password, RedirectAttributes redirectAttributes) {
//        if (nguoiDungService.existsByUsername(username)) {
//            redirectAttributes.addFlashAttribute("error", "Tên đăng nhập đã tồn tại");
//            return "redirect:/register";
//        }
//        NguoiDungEntity newUser = new NguoiDungEntity();
//        newUser.setUsername(username);
//        newUser.setMatKhau(passwordEncoder.encode(password));
//        newUser.setVaiTro("KhachHang");
//        newUser.setTrangThai("HoatDong");
//        nguoiDungService.save(newUser);
//        redirectAttributes.addFlashAttribute("success", "Đăng ký thành công! Hãy đăng nhập.");
//        return "redirect:/login";
//    }
}